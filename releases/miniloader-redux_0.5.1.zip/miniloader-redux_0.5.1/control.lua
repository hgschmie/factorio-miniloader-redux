------------------------------------------------------------------------
-- runtime code
------------------------------------------------------------------------

require('lib.init')

-- setup events
require('scripts.event-setup')

-- other mods code
Framework.post_runtime_stage()
